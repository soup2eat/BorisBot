const Discord = require('discord.js');

const bot = new Discord.Client();

const cheerio = require('cheerio');

const request = require('request');

const token = 'NjQyNjA5OTUyMDc4NDMwMjA5.XcZbLw.jIJqeiVORmuKHWh5FOHBnZ3ohUQ';

const PREFIX = 'Mr. '

bot.on('ready',() =>{
    console.log('This bot is online!');
})

bot.on('message', msg =>{
    let args = msg.content.substring(PREFIX.length).split(" ");

    switch (args[0]){
        case 'Boris':
            msg.channel.sendMessage('@everyone')
            break;
        case 'image':
            image(msg);

            break;
    }
})

function image(msg){
    var 
}
bot.login(token);